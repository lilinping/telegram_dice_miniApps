'use client';

import { createContext, useContext, useState, ReactNode, useCallback, useEffect, useRef } from 'react';
import { apiService } from '@/lib/api';
import { useTelegram } from './TelegramContext';
import { useWallet } from './WalletContext';
import { DiceEntity, DiceChooseVO, StopPeriod } from '@/lib/types';
import { getBetChooseId } from '@/lib/betMapping';
import { toast } from '@/components/ui/Toast';

type GameState = 'betting' | 'rolling' | 'revealing' | 'settled';

interface BetHistoryItem {
  betId: string;
  amount: number;
}

interface GameContextType {
  // 游戏状态
  gameState: GameState;
  setGameState: (state: GameState) => void;

  // 当前局信息
  currentGameId: string | null;
  currentRound: number;
  countdown: number;
  setCountdown: (time: number) => void;

  // 下注选项
  diceOptions: Map<number, DiceChooseVO>;
  loadDiceOptions: () => Promise<void>;

  // 下注相关
  selectedChip: number;
  setSelectedChip: (chip: number) => void;
  bets: Record<string, number>;
  placeBet: (betId: string) => void;
  clearBets: () => void;
  confirmBets: () => Promise<boolean>;

  // 倍投功能
  multiplier: number;
  setMultiplier: (multiplier: number) => void;

  // 撤销功能
  betHistory: BetHistoryItem[];
  undoLastBet: () => void;
  canUndo: boolean;

  // 重复上局下注
  lastBets: Record<string, number>;
  repeatLastBets: () => void;

  // 开奖结果
  diceResults: number[];
  setDiceResults: (results: number[]) => void;

  // 中奖信息
  winAmount: number;
  hasWon: boolean;

  // 停盘控制
  stopPeriods: StopPeriod[];
  currentStopPeriod: StopPeriod | null;
  isBettingBlocked: boolean;
  refreshStopPeriods: (force?: boolean) => Promise<void>;
  getStopPeriodToastMessage: () => string;

  // 游戏控制
  startNewGame: () => Promise<void>;
  endCurrentGame: () => Promise<void>;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

const normalizeAmount = (value: number) => {
  return Math.round((value + Number.EPSILON) * 100) / 100;
};

type NormalizedStopPeriod = StopPeriod & {
  startTimestamp: number | null;
  endTimestamp: number | null;
};

const parseTimestamp = (value?: number | string | null): number | null => {
  if (value === undefined || value === null) return null;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return null;
    return value > 1e12 ? value : value * 1000;
  }
  const numeric = Number(value);
  if (!Number.isNaN(numeric)) {
    return numeric > 1e12 ? numeric : numeric * 1000;
  }
  const parsed = Date.parse(String(value));
  return Number.isNaN(parsed) ? null : parsed;
};

const normalizeStopPeriod = (period: StopPeriod): NormalizedStopPeriod => ({
  ...period,
  startTimestamp: parseTimestamp(period.startTime ?? null),
  endTimestamp: parseTimestamp(period.endTime ?? null),
});

const STOP_PERIOD_FETCH_CACHE_MS = 60 * 1000;
const STOP_PERIOD_CHECK_INTERVAL_MS = 30 * 1000;

export function GameProvider({ children }: { children: ReactNode }) {
  const { user } = useTelegram();
  const { refreshBalance } = useWallet();
  const [gameState, setGameState] = useState<GameState>('betting');
  const [currentGameId, setCurrentGameId] = useState<string | null>(null);
  const [currentRound, setCurrentRound] = useState(123456);
  const [countdown, setCountdown] = useState(30);
  
  // 中奖信息状态
  const [winAmount, setWinAmount] = useState(0);
  const [hasWon, setHasWon] = useState(false);
  const [selectedChip, setSelectedChip] = useState(1);
  const [bets, setBets] = useState<Record<string, number>>({});
  const [diceResults, setDiceResults] = useState<number[]>([]);
  const [diceOptions, setDiceOptions] = useState<Map<number, DiceChooseVO>>(new Map());

  // 倍投状态
  const [multiplier, setMultiplier] = useState(1);

  // 撤销功能：下注历史栈
  const [betHistory, setBetHistory] = useState<BetHistoryItem[]>([]);

  // 上一局下注记录
  const [lastBets, setLastBets] = useState<Record<string, number>>({});

  // 停盘状态
  const [stopPeriods, setStopPeriods] = useState<StopPeriod[]>([]);
  const [currentStopPeriod, setCurrentStopPeriod] = useState<StopPeriod | null>(null);
  const [isBettingBlocked, setIsBettingBlocked] = useState(false);

  // 记住用户的选择（筹码、倍数和下注区域）- 从 localStorage 恢复
  const [rememberedChip, setRememberedChip] = useState<number | null>(() => {
    if (typeof window === 'undefined') return 1;
    const saved = localStorage.getItem('dice_remembered_chip');
    return saved ? Number(saved) : 1;
  });
  const [rememberedMultiplier, setRememberedMultiplier] = useState<number | null>(() => {
    if (typeof window === 'undefined') return null;
    const saved = localStorage.getItem('dice_remembered_multiplier');
    return saved ? Number(saved) : null;
  });
  const [rememberedBets, setRememberedBets] = useState<Record<string, number>>(() => {
    if (typeof window === 'undefined') return {};
    const saved = localStorage.getItem('dice_remembered_bets');
    return saved ? JSON.parse(saved) : {};
  });

  // 防止Strict Mode重复调用
  const diceOptionsLoadedRef = useRef(false);
  const startingGameRef = useRef(false);
  const normalizedStopPeriodsRef = useRef<NormalizedStopPeriod[]>([]);
  const stopPeriodCheckTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const stopPeriodDailyTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastStopFetchRef = useRef(0);
  const refreshStopPeriodsRef = useRef<((force?: boolean) => Promise<void>) | null>(null);

  // 加载骰宝选项对照表
  const loadDiceOptions = useCallback(async () => {
    try {
      const response = await apiService.getDiceDisplay();
      if (response.success && response.data) {
        // 将对象转换为Map
        const optionsMap = new Map<number, DiceChooseVO>();
        Object.entries(response.data).forEach(([key, value]) => {
          optionsMap.set(Number(key), value as DiceChooseVO);
        });
        setDiceOptions(optionsMap);
        console.log('骰宝选项加载成功:', optionsMap);
      }
    } catch (error) {
      console.error('加载骰宝选项失败:', error);
    }
  }, []);

  // 初始化时加载骰宝选项
  useEffect(() => {
    if (diceOptionsLoadedRef.current) return;
    diceOptionsLoadedRef.current = true;
    loadDiceOptions();
  }, [loadDiceOptions]);

  const evaluateStopPeriods = useCallback((currentFromApi?: StopPeriod | null) => {
    let effective: StopPeriod | null = currentFromApi || null;
    const now = Date.now();

    if (!effective) {
      for (const period of normalizedStopPeriodsRef.current) {
        const start = period.startTimestamp;
        const end = period.endTimestamp;
        if (start === null || end === null) continue;
        if (now >= start && now <= end) {
          effective = period;
          break;
        }
      }
    }

    setCurrentStopPeriod(effective || null);
    setIsBettingBlocked(!!effective);
  }, []);

  const refreshStopPeriods = useCallback(async (force: boolean = false) => {
    const now = Date.now();
    if (!force && now - lastStopFetchRef.current < STOP_PERIOD_FETCH_CACHE_MS) {
      return;
    }

    lastStopFetchRef.current = now;

    try {
      const [listRes, currentRes] = await Promise.all([
        apiService.getStopTimes(),
        apiService.getCurrentStopPeriod(),
      ]);

      if (listRes.success && Array.isArray(listRes.data)) {
        setStopPeriods(listRes.data);
        normalizedStopPeriodsRef.current = listRes.data.map(normalizeStopPeriod);
      }

      const currentPeriod = currentRes.success ? currentRes.data ?? null : null;
      evaluateStopPeriods(currentPeriod);
    } catch (error) {
      console.error('刷新停盘时间失败:', error);
      evaluateStopPeriods();
    }
  }, [evaluateStopPeriods]);

  useEffect(() => {
    refreshStopPeriodsRef.current = refreshStopPeriods;
    return () => {
      refreshStopPeriodsRef.current = null;
    };
  }, [refreshStopPeriods]);

  // 只在组件挂载时或 user 变化时刷新停盘时间（避免重复请求）
  useEffect(() => {
    // 只有当 user 存在时才刷新
    if (user) {
      refreshStopPeriods(true);
    }
  }, [user?.id]); // 只依赖 user.id，避免 user 对象变化导致重复请求

  useEffect(() => {
    if (stopPeriodCheckTimerRef.current) {
      clearInterval(stopPeriodCheckTimerRef.current);
    }

    const timer = setInterval(() => {
      evaluateStopPeriods();
    }, STOP_PERIOD_CHECK_INTERVAL_MS);

    stopPeriodCheckTimerRef.current = timer;
    evaluateStopPeriods();

    return () => {
      if (stopPeriodCheckTimerRef.current) {
        clearInterval(stopPeriodCheckTimerRef.current);
        stopPeriodCheckTimerRef.current = null;
      }
    };
  }, [evaluateStopPeriods]);

  useEffect(() => {
    const scheduleNextFetch = () => {
      if (stopPeriodDailyTimerRef.current) {
        clearTimeout(stopPeriodDailyTimerRef.current);
      }

      const now = new Date();
      const next = new Date(now);
      next.setDate(now.getDate() + 1);
      next.setHours(0, 0, 5, 0);
      const delay = Math.max(60 * 1000, next.getTime() - now.getTime());

      stopPeriodDailyTimerRef.current = setTimeout(async () => {
        try {
          await refreshStopPeriodsRef.current?.(true);
        } finally {
          scheduleNextFetch();
        }
      }, delay);
    };

    scheduleNextFetch();

    return () => {
      if (stopPeriodDailyTimerRef.current) {
        clearTimeout(stopPeriodDailyTimerRef.current);
        stopPeriodDailyTimerRef.current = null;
      }
    };
  }, []);

  const getStopPeriodToastMessage = useCallback(() => {
    if (currentStopPeriod?.desc) {
      return currentStopPeriod.desc;
    }
    const start = parseTimestamp(currentStopPeriod?.startTime ?? null);
    const end = parseTimestamp(currentStopPeriod?.endTime ?? null);
    if (start && end) {
      return `当前停盘 (${new Date(start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - ${new Date(end).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})`;
    }
    return '当前处于停盘时间，暂时无法下注';
  }, [currentStopPeriod]);

  // 开始新游戏
  const startNewGame = useCallback(async () => {
    if (!user) {
      console.error('用户未登录');
      return;
    }

    if (startingGameRef.current) {
      console.log('游戏正在启动中，跳过重复请求');
      return;
    }

    startingGameRef.current = true;

    try {
      const response = await apiService.startGame(String(user.id));
      if (response.success && response.data) {
        setCurrentGameId(response.data);
        setGameState('betting');
        setCountdown(30);
        
        // 恢复用户上次选择的筹码、倍数和下注区域（如果用户之前下过注）
        if (rememberedChip !== null) {
          setSelectedChip(rememberedChip);
        }
        if (rememberedMultiplier !== null) {
          setMultiplier(rememberedMultiplier);
        }
        // 恢复下注区域
        if (Object.keys(rememberedBets).length > 0) {
          setBets({ ...rememberedBets });
          // 重建历史栈
          const history: BetHistoryItem[] = [];
          Object.entries(rememberedBets).forEach(([betId, amount]) => {
            history.push({ betId, amount });
          });
          setBetHistory(history);
        }
        
        console.log('游戏开始，gameId:', response.data, '恢复筹码:', rememberedChip, '恢复倍数:', rememberedMultiplier, '恢复下注区域:', rememberedBets);
      } else {
        console.error('开始游戏失败:', response.message);
      }
    } catch (error) {
      console.error('开始游戏失败:', error);
    } finally {
      startingGameRef.current = false;
    }
  }, [user, rememberedChip, rememberedMultiplier, rememberedBets]);

  // 结束当前游戏
  const endCurrentGame = useCallback(async () => {
    if (!currentGameId) {
      console.error('没有正在进行的游戏');
      return;
    }

    try {
      const response = await apiService.endGame(currentGameId);
      if (response.success) {
        console.log('游戏结束');
      } else {
        console.error('结束游戏失败:', response.message);
      }
    } catch (error) {
      console.error('结束游戏失败:', error);
    }
  }, [currentGameId]);

  // 下注（考虑倍投）
  const placeBet = useCallback(
    (betId: string) => {
      if (isBettingBlocked) {
        toast.error(getStopPeriodToastMessage());
        return;
      }

      if (gameState !== 'betting' || countdown === 0) {
        return;
      }

      const actualAmount = normalizeAmount(selectedChip * multiplier);

      // 检查该下注选项是否有policy限制
      try {
        const chooseId = getBetChooseId(betId);
        if (chooseId !== null) {
          const option = diceOptions.get(chooseId);
          if (option && option.policy) {
            const min = option.policy.min ? parseFloat(String(option.policy.min)) : undefined;
            const max = option.policy.max ? parseFloat(String(option.policy.max)) : undefined;
            const current = bets[betId] || 0;
            const newTotal = normalizeAmount(current + actualAmount);
            if (min !== undefined && newTotal < min) {
              toast.error(`该选项最小下注为 ${min}，当前筹码不足以达成。`);
              return;
            }
            if (max !== undefined && newTotal > max) {
              toast.error(`该选项最大下注为 ${max}，请调整筹码或倍数。`);
              return;
            }
          }
        }
      } catch (e) {
        console.warn('policy 校验失败，继续下注', e);
      }

      setBets((prev) => ({
        ...prev,
        [betId]: normalizeAmount((prev[betId] || 0) + actualAmount),
      }));

      // 记录到历史栈（用于撤销）
      setBetHistory((prev) => [...prev, { betId, amount: actualAmount }]);
    },
    [gameState, countdown, selectedChip, multiplier, isBettingBlocked, getStopPeriodToastMessage]
  );

  // 清空下注
  const clearBets = useCallback(async () => {
    if (!currentGameId) return;

    try {
      // 调用后端撤销所有下注
      const response = await apiService.revertAllBets(currentGameId);
      if (response.success) {
        setBets({});
        setBetHistory([]);
        // 清空记忆的下注区域
        setRememberedBets({});
        if (typeof window !== 'undefined') {
          localStorage.removeItem('dice_remembered_bets');
        }
        console.log('所有下注已清空');
        try {
          // 刷新余额，确保撤回后金额回到用户账户
          await refreshBalance();
        } catch (e) {
          console.warn('刷新余额失败（clearBets）', e);
        }
      } else {
        console.error('清空下注失败:', response.message);
      }
    } catch (error) {
      console.error('清空下注失败:', error);
      // 即使后端失败，也清空前端状态
      setBets({});
      setBetHistory([]);
      // 清空记忆的下注区域
      setRememberedBets({});
      if (typeof window !== 'undefined') {
        localStorage.removeItem('dice_remembered_bets');
      }
      try {
        // 尝试刷新余额，防止前端状态与余额不一致
        await refreshBalance();
      } catch (e) {
        console.warn('刷新余额失败（clearBets fallback）', e);
      }
    }
  }, [currentGameId, refreshBalance]);

  // 撤销上一步下注
  const undoLastBet = useCallback(async () => {
    if (betHistory.length === 0 || !currentGameId) return;

    const lastBet = betHistory[betHistory.length - 1];

    try {
      // 调用后端撤销接口
      const chooseId = getBetChooseId(lastBet.betId);
      if (chooseId === null) {
        console.error(`无效的下注选项: ${lastBet.betId}`);
        return;
      }
      const response = await apiService.revertBet(currentGameId, chooseId);
      if (response.success) {
        setBets((prev) => {
          const newBets = { ...prev };
          const newAmount = normalizeAmount((newBets[lastBet.betId] || 0) - lastBet.amount);

          if (newAmount <= 0) {
            delete newBets[lastBet.betId];
          } else {
            newBets[lastBet.betId] = newAmount;
          }

          return newBets;
        });

        setBetHistory((prev) => prev.slice(0, -1));
        console.log('撤销下注成功');
        try {
          // 刷新余额，确保撤回金额回到用户账户
          await refreshBalance();
        } catch (e) {
          console.warn('刷新余额失败（undoLastBet）', e);
        }
      } else {
        console.error('撤销下注失败:', response.message);
      }
    } catch (error) {
      console.error('撤销下注失败:', error);
      try {
        // 在异常情况下仍然尝试刷新余额，避免前端与后端不一致
        await refreshBalance();
      } catch (e) {
        console.warn('刷新余额失败（undoLastBet fallback）', e);
      }
    }
  }, [betHistory, currentGameId, refreshBalance]);

  // 重复上局下注
  const repeatLastBets = useCallback(() => {
    if (Object.keys(lastBets).length === 0) return;

    setBets(lastBets);
    // 重建历史栈
    const history: BetHistoryItem[] = [];
    Object.entries(lastBets).forEach(([betId, amount]) => {
      history.push({ betId, amount });
    });
    setBetHistory(history);
  }, [lastBets]);

  // 确认下注
  const confirmBets = useCallback(async () => {
    if (isBettingBlocked) {
      toast.error(getStopPeriodToastMessage());
      return false;
    }

    if (!currentGameId || !user) {
      console.error('游戏未开始或用户未登录');
      return false;
    }

    try {
      // 在提交前对每个下注项做一次 policy 校验，避免客户端将违规下注发送到后端
      for (const [betId, amount] of Object.entries(bets)) {
        const chooseId = getBetChooseId(betId);
        if (chooseId === null) {
          throw new Error(`无效的下注选项: ${betId}`);
        }
        const option = diceOptions.get(chooseId);
        if (option && option.policy) {
          const min = option.policy.min ? parseFloat(String(option.policy.min)) : undefined;
          const max = option.policy.max ? parseFloat(String(option.policy.max)) : undefined;
          if (min !== undefined && amount < min) {
            toast.error(`下注金额低于该选项最小限制：${min}`);
            return false;
          }
          if (max !== undefined && amount > max) {
            toast.error(`下注金额超过该选项最大限制：${max}`);
            return false;
          }
        }
      }

      const betEntries = Object.entries(bets);
      if (betEntries.length === 0) {
        toast.warning('请先选择投注项');
        return false;
      }

      const mappedBets = betEntries.map(([betId, amount]) => {
        const chooseId = getBetChooseId(betId);
        if (chooseId === null) {
          throw new Error(`无效的下注选项: ${betId}`);
        }
        return { chooseId, bet: String(amount), betId };
      });

      let submitSuccess = false;
      if (mappedBets.length === 1) {
        const { chooseId, bet } = mappedBets[0];
        const res = await apiService.placeBet(currentGameId, chooseId, bet);
        submitSuccess = !!res.success;
      } else {
        const multiPayload = mappedBets.map(({ chooseId, bet }) => ({ chooseId, bet: Number(bet) }));
        const res = await apiService.placeMultiBet(currentGameId, multiPayload);
        submitSuccess = !!res.success;
      }

      if (!submitSuccess) {
        console.error('批量下注失败');
        toast.error('下注失败，请稍后重试');
        return false;
      }

      console.log('所有下注提交成功');

      // 保存为上一局下注
      setLastBets(bets);

      // 记住用户选择的筹码、倍数和下注区域，并持久化到 localStorage
      setRememberedChip(selectedChip);
      setRememberedMultiplier(multiplier);
      setRememberedBets({ ...bets }); // 深拷贝保存下注区域
      
      // 持久化到 localStorage
      if (typeof window !== 'undefined') {
        localStorage.setItem('dice_remembered_chip', String(selectedChip));
        localStorage.setItem('dice_remembered_multiplier', String(multiplier));
        localStorage.setItem('dice_remembered_bets', JSON.stringify(bets));
      }

      // 立即进入rolling状态，提供即时反馈
      setGameState('rolling');
      const rollStartTime = Date.now();

      // 异步获取结果，不阻塞动画
      const handleResultFlow = async () => {
        try {
          // 结束游戏并获取结果
          await endCurrentGame();

          // 查询游戏结果
          const gameResult = await apiService.queryGame(currentGameId);
          if (!gameResult.success || !gameResult.data) {
            console.error('查询游戏结果失败:', gameResult);
            // 设置默认结果，避免动画卡住
            const fallbackResults = [
              Math.floor(Math.random() * 6) + 1,
              Math.floor(Math.random() * 6) + 1,
              Math.floor(Math.random() * 6) + 1
            ];
            console.warn('使用随机结果作为兜底:', fallbackResults);
            setDiceResults(fallbackResults);
            return;
          }

          const result = gameResult.data;

          // 设置骰子结果（静默更新，不影响正在进行的动画）
          if (result.outCome && result.outCome.length === 3) {
            console.log('设置骰子结果:', result.outCome);
            setDiceResults(result.outCome);
          } else {
            console.error('骰子结果数据异常:', result.outCome);
            // 设置默认结果，避免动画卡住
            const fallbackResults = [
              Math.floor(Math.random() * 6) + 1,
              Math.floor(Math.random() * 6) + 1,
              Math.floor(Math.random() * 6) + 1
            ];
            console.warn('使用随机结果作为兜底:', fallbackResults);
            setDiceResults(fallbackResults);
          }

          // 提取中奖信息
          const winValue = parseFloat(result.win || '0');
          console.log('🎰 游戏结果 - win字段:', result.win, '解析后:', winValue);
          setWinAmount(winValue);
          setHasWon(winValue > 0);
          console.log('🎰 设置中奖状态 - hasWon:', winValue > 0, 'winAmount:', winValue);

          // 下单成功后刷新余额
          await refreshBalance();
        } catch (error) {
          console.error('获取游戏结果失败:', error);
          // 设置默认结果，避免动画卡住
          const fallbackResults = [
            Math.floor(Math.random() * 6) + 1,
            Math.floor(Math.random() * 6) + 1,
            Math.floor(Math.random() * 6) + 1
          ];
          console.warn('异常情况使用随机结果作为兜底:', fallbackResults);
          setDiceResults(fallbackResults);
        }
      };


      // 启动异步流程获取结果（不阻塞动画）
      handleResultFlow();

      // 动画时间线（不等待API，固定时间）
      setTimeout(() => {
        setGameState('revealing');
      }, 2300); // rolling阶段2.3秒

      setTimeout(() => {
        setGameState('settled');
      }, 5300); // revealing阶段3秒

      setTimeout(async () => {
        setGameState('betting');
        // 注意：不清空diceResults，保留上一局结果显示
        // setDiceResults([]);  // 注释掉，让骰子保持显示上一局结果
        // 不在这里清空bets，让startNewGame根据记住的值来恢复
        // setBets({});
        // setBetHistory([]);
        // 不在这里重置multiplier，让startNewGame根据记住的值来恢复
        setCurrentRound((prev) => prev + 1);
        
        // 重置中奖信息
        setWinAmount(0);
        setHasWon(false);

        // 自动开始下一局（会自动恢复记住的筹码、倍数和下注区域）
        await startNewGame();
      }, 8300); // settled阶段延长至4秒（展示时间+2秒）

      return true;
    } catch (error) {
      console.error('确认下注失败:', error);
      return false;
    }
  }, [bets, currentGameId, user, endCurrentGame, startNewGame, refreshBalance, selectedChip, multiplier, isBettingBlocked, getStopPeriodToastMessage]);

  // 自动开始第一局游戏
  useEffect(() => {
    if (user && !currentGameId) {
      startNewGame();
    }
  }, [user, currentGameId, startNewGame]);

  return (
    <GameContext.Provider
      value={{
        gameState,
        setGameState,
        currentGameId,
        currentRound,
        countdown,
        setCountdown,
        diceOptions,
        loadDiceOptions,
        selectedChip,
        setSelectedChip,
        bets,
        placeBet,
        clearBets,
        confirmBets,
        multiplier,
        setMultiplier,
        betHistory,
        undoLastBet,
        canUndo: betHistory.length > 0,
        lastBets,
        repeatLastBets,
        diceResults,
        setDiceResults,
        winAmount,
        hasWon,
        stopPeriods,
        currentStopPeriod,
        isBettingBlocked,
        refreshStopPeriods,
        getStopPeriodToastMessage,
        startNewGame,
        endCurrentGame,
      }}
    >
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within GameProvider');
  }
  return context;
}
