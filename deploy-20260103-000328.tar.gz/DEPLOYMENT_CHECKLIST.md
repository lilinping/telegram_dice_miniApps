# 部署检查清单

## ✅ 部署前检查

### 1. 后端 API 认证
- [ ] 确认后端 API 需要 `initData` 请求头
- [ ] 前端已添加 `initData` 请求头（在 `src/lib/api.ts` 中）
- [ ] API 路由已配置转发 `initData` 请求头（在 `src/app/api/backend/[...path]/route.ts` 中）

### 2. 环境变量配置
- [ ] 在 Vercel Dashboard 中设置 `BACKEND_API_URL`
- [ ] 在 Vercel Dashboard 中设置 `NEXT_PUBLIC_TELEGRAM_BOT_TOKEN`
- [ ] 在 Vercel Dashboard 中设置 `NEXT_PUBLIC_USDT_TRC20_ADDRESS`

### 3. 代码检查
- [ ] 运行 `npm run build` 确保构建成功
- [ ] 检查 TypeScript 错误
- [ ] 检查 ESLint 警告

## 🚀 部署步骤

### 方法 1: 使用部署脚本
```bash
./deploy-vercel.sh
```

### 方法 2: 手动部署
```bash
# 1. 构建项目
npm run build

# 2. 部署到 Vercel
vercel --prod

# 3. 设置环境变量（如果还没设置）
vercel env add BACKEND_API_URL production
vercel env add NEXT_PUBLIC_TELEGRAM_BOT_TOKEN production
vercel env add NEXT_PUBLIC_USDT_TRC20_ADDRESS production
```

## 🧪 部署后测试

### 1. 基础功能测试
- [ ] 在 Telegram 中打开 Mini App
- [ ] 检查用户信息是否正确加载
- [ ] 检查余额是否显示

### 2. 游戏功能测试
- [ ] 开始新游戏
- [ ] 选择筹码并下注
- [ ] 查看开奖结果
- [ ] 检查余额变化

### 3. 钱包功能测试
- [ ] 查看钱包余额
- [ ] 测试充值流程
- [ ] 测试提现流程
- [ ] 查看交易历史

### 4. API 测试
打开浏览器开发者工具，检查网络请求：

- [ ] 所有 API 请求都通过 `/api/backend` 代理
- [ ] 请求头包含 `initData`
- [ ] 没有 401 错误
- [ ] 没有 CORS 错误

## 🐛 常见问题排查

### 问题 1: 401 Unauthorized

**原因**: 缺少 `initData` 请求头

**解决方案**:
1. 确保在 Telegram 中打开应用（不要直接在浏览器中访问）
2. 检查 `src/lib/api.ts` 中是否正确获取 `initData`
3. 检查 API 路由是否正确转发 `initData` 请求头

**验证**:
```javascript
// 在浏览器控制台运行
console.log(window.Telegram?.WebApp?.initData);
// 应该输出一个长字符串，而不是 undefined
```

### 问题 2: CORS 错误

**原因**: 直接访问后端 API，而不是通过代理

**解决方案**:
1. 确保所有 API 请求都使用 `/api/backend` 前缀
2. 检查 `src/lib/api.ts` 中的 `API_BASE_URL` 配置
3. 不要在客户端代码中直接使用 `http://46.250.168.177:8079`

### 问题 3: 环境变量未生效

**原因**: 修改环境变量后未重新部署

**解决方案**:
```bash
# 重新部署
vercel --prod

# 或在 Vercel Dashboard 中点击 "Redeploy"
```

### 问题 4: 开发环境无法测试

**原因**: 本地开发时没有 Telegram WebApp 环境

**解决方案**:
1. 使用开发环境模拟工具（已自动启用）
2. 或使用 ngrok 等工具将本地服务暴露到公网，然后在 Telegram 中测试

```bash
# 使用 ngrok
ngrok http 3000

# 将 ngrok 提供的 URL 设置为 Telegram Bot 的 Web App URL
```

## 📊 监控和日志

### Vercel Dashboard
1. **Functions 日志**: 查看 API 路由的执行日志
2. **Analytics**: 查看访问统计
3. **Speed Insights**: 查看性能指标

### 浏览器开发者工具
1. **Network**: 查看 API 请求和响应
2. **Console**: 查看错误日志
3. **Application > Local Storage**: 查看存储的数据

## 🔒 安全检查

- [ ] 不要在客户端代码中暴露敏感信息
- [ ] 使用环境变量存储 API 密钥
- [ ] 确保 `initData` 在后端进行验证
- [ ] 定期更新依赖包

## 📝 部署记录

| 日期 | 版本 | 部署者 | 备注 |
|------|------|--------|------|
| 2024-12-02 | 1.0.0 | - | 初始部署，添加 initData 认证 |

## 🔗 相关链接

- [Vercel Dashboard](https://vercel.com/dashboard)
- [Telegram Bot API](https://core.telegram.org/bots/api)
- [Telegram WebApp API](https://core.telegram.org/bots/webapps)
- [Next.js API Routes](https://nextjs.org/docs/api-routes/introduction)
