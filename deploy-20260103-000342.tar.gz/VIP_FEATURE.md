# VIP会员功能实现

## 功能说明

根据Telegram用户的`is_premium`字段判断用户是否为VIP会员，并提供VIP升级入口。

## 实现细节

### 1. TelegramContext 添加 isPremium 字段

在 `src/contexts/TelegramContext.tsx` 中：

```typescript
interface TelegramUser {
  id: number;
  firstName?: string;
  lastName?: string;
  username?: string;
  languageCode?: string;
  photoUrl?: string;
  isPremium?: boolean; // Telegram Premium 用户
}

// 获取用户信息时包含 is_premium
const userObj: TelegramUser = {
  id: telegramUser.id,
  firstName: telegramUser.first_name,
  lastName: telegramUser.last_name,
  username: telegramUser.username,
  languageCode: telegramUser.language_code,
  photoUrl: telegramUser.photo_url,
  isPremium: telegramUser.is_premium || false,
};
```

### 2. 个人页面根据 isPremium 显示VIP状态

在 `src/app/profile/page.tsx` 中：

```typescript
const isPremiumUser = user?.isPremium || false;

const userData = {
  // ...
  vipLevel: isPremiumUser ? 1 : 0, // VIP会员为1，普通用户为0
};
```

### 3. VIP等级配置

```typescript
const vipLevels = [
  { level: 0, name: '普通用户', color: '#808080', icon: '👤' },
  { level: 1, name: 'VIP会员', color: '#FFD700', icon: '⭐' },
  // ... 其他等级
];
```

### 4. VIP升级入口

#### 4.1 头像旁的VIP标签可点击
- VIP用户：显示"VIP会员"，不可点击
- 普通用户：显示"普通用户"，点击跳转到充值页面

#### 4.2 VIP升级提示卡片（仅对普通用户显示）
- 显示在用户信息卡片下方
- 金色渐变背景，醒目的升级按钮
- 点击跳转到 `https://t.me/dhtpay_bot?start=premium`

## 用户体验

### VIP用户
- 头像右上角显示金色"VIP会员"标签
- 不显示升级提示卡片
- 享受VIP特权（后续可扩展）

### 普通用户
- 头像右上角显示灰色"普通用户"标签
- 显示金色的VIP升级提示卡片
- 点击任意入口跳转到Telegram Bot充值页面

## 充值流程

1. 用户点击"升级VIP会员"或"普通用户"标签
2. 跳转到 `https://t.me/dhtpay_bot?start=premium`
3. 在Telegram Bot中完成充值
4. 充值成功后，用户的`is_premium`字段会更新
5. 返回应用，刷新页面即可看到VIP状态

## 技术细节

### Telegram Premium 判断
```typescript
// Telegram WebApp API 提供的用户信息
const telegramUser = tg.initDataUnsafe?.user;

// is_premium 字段
// - true: Telegram Premium 用户
// - false 或 undefined: 普通用户
const isPremium = telegramUser.is_premium || false;
```

### 外部链接跳转
```typescript
// 使用 window.open 在新标签页打开
window.open('https://t.me/dhtpay_bot?start=premium', '_blank');
```

## 界面展示

### 普通用户
```
┌─────────────────────────────────────┐
│  👤  小小福                    普通用户 │
│  @xxf01                              │
│  UID: 5103308953                     │
│                                      │
│  累计投注    累计中奖    胜率         │
│  9,316      5,296      22.3%        │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  ⭐  升级VIP会员              →      │
│     享受专属特权和优惠               │
└─────────────────────────────────────┘
```

### VIP用户
```
┌─────────────────────────────────────┐
│  ⭐  小小福                   VIP会员 │
│  @xxf01                              │
│  UID: 5103308953                     │
│                                      │
│  累计投注    累计中奖    胜率         │
│  9,316      5,296      22.3%        │
└─────────────────────────────────────┘

（不显示升级提示）
```

## 后续扩展

### 1. VIP特权
- 更高的下注限额
- 专属客服
- 更高的返水比例
- 专属活动和奖励

### 2. VIP等级体系
可以根据用户的投注额或其他指标，设置多个VIP等级：
- VIP 1: Telegram Premium 用户
- VIP 2-5: 根据投注额升级

### 3. VIP到期提醒
如果VIP有时效性，可以添加到期提醒功能。

## 测试步骤

### 测试1：普通用户
1. 使用非Premium的Telegram账号登录
2. 进入个人页面
3. **验证**：
   - 显示"普通用户"标签
   - 显示金色的VIP升级提示卡片
   - 点击标签或卡片，跳转到充值页面

### 测试2：VIP用户
1. 使用Telegram Premium账号登录
2. 进入个人页面
3. **验证**：
   - 显示"VIP会员"标签（金色）
   - 不显示升级提示卡片
   - VIP标签不可点击

### 测试3：充值流程
1. 作为普通用户，点击升级按钮
2. 跳转到 `https://t.me/dhtpay_bot?start=premium`
3. 在Bot中完成充值
4. 返回应用，刷新页面
5. **验证**：VIP状态已更新

## 修改文件
- `src/contexts/TelegramContext.tsx` - 添加 isPremium 字段
- `src/app/profile/page.tsx` - 实现VIP显示和升级功能
